
=> 13.0.0.1 : Improved index module link version or related apps image.

=> 13.0.0.2 : - Fixed the error generated while changing product cost
			  - Fixed error while creating invoice from sale order. 
			  - Improved view of invoice. 
			  - Improved the code of account move to save the newly added values in draft invoice and calculate discount accordingly.	

=> 13.0.0.3: - Fixed issue of wrong line discount calculation in sale order and customer invoice. 

=> 13.0.0.4: - Resolved the issue of wrong tax calculation when discount setting is untaxed and no discount 			   method or amount is given in invoice. 


==>13.0.0.5 : improved points=>--> Remove the Discount amount,discount method,tax , Discount type from the Quotation report, Sale order report and Invoice report not from the backend odoo..

--> Change the name of the Line Discount --> 'Total Discount'

--> Add the column of the discounted unit price on the sale order line .

==>13.0.0.6:added checkbox of untax amount in setting and added discounted unit price in invoice line.			  